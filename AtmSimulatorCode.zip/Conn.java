package ASimulatorSystem;

import java.sql.*;  

public class Conn{
    Connection c;
    Statement s;
    public Conn(){  
        try{  
            Class.forName("com.mysql.cj.jdbc.Driver");  
            c =DriverManager.getConnection("jdbc:mysql://localhost:3306/bms","root","Dinesh");    
            s =c.createStatement(); 
           
        }catch(Exception e){ 
            System.out.println(e);
        }  
    }  
}  

/*
1.Register the Driver
2.Create Connection
3.Create Statement
4.Excecute query
5.Close conn
*/